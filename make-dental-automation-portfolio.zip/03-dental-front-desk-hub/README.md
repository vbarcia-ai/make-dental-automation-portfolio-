# 03 - Dental Front Desk Hub (Notion, Demo)

**Tools:** Notion
**Status:** Demo workspace concept with fictional data. The screenshot is a
sanitized recreation, not captures of a live workspace.

## The problem

A small clinic's daily front desk work lives in many places: the appointment
book, recall lists, task notes, supply counts and procedures. Information gets
lost between them.

## What this demo does

A single Notion workspace organizes the daily work of a small clinic:

- **Patient directory** - one record per patient.
- **Appointment board** - today's schedule with statuses (confirmed, pending,
  reminder sent).
- **Recall tracker** - who is due back and when.
- **Front desk tasks** - the daily to-do list of the reception team.
- **Supply inventory** - stock levels for clinic supplies.
- **Clinic SOPs** - standard procedures in one place.

## What this project demonstrates

- Designing an organized operations workspace for a dental front desk.
- Structuring databases, views and statuses so the day can be run from one
  screen.

## Data note

The workflow is modeled on the reception workflow of my own dental practice;
all names and details shown are fictional demo data.

## Screenshots

| File | Shows |
|---|---|
| `screenshots/01-hub-demo-concept.png` | The hub concept: today's schedule with fictional patients and the module list |

The screenshot is labeled as a demo concept with fictional data.
