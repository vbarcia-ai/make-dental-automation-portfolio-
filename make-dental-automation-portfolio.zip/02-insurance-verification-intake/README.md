# 02 - Dental Insurance Verification Intake (Demo)

**Tools:** Google Forms, Google Sheets, Make, Gmail
**Status:** Configured intake demo with fictional data. It is not a live
insurance eligibility service and does not connect to any insurer. No complete
end-to-end test or real verification is claimed.

## The problem

Dental insurance checks require complete intake information and a clear
checklist. Missing details (subscriber, group number, procedure codes) delay
verification, and the front desk loses track of which case is at which stage.

## What this demo does

1. **Intake form (Google Forms):** collects the case details needed for a
   verification: patient and subscriber data, carrier, group and member IDs,
   and the procedure / CDT codes to check.
2. **Tracker (Google Sheets):** form answers land in a tracker. Each case gets
   a Case ID and moves through a status flow:
   `Pending -> Missing Information -> Verified -> Closed`.
3. **Watch New Rows (Make):** the scenario picks up each new tracker row.
4. **Send an email (Gmail):** prepares a verification checklist email covering
   eligibility, deductible, coverage percentage, waiting periods and the
   missing tooth clause, with the case details mapped in.
5. **Update a Row (Google Sheets):** marks the checklist as sent so the case
   can be followed up.

## What this project demonstrates

- Structured intake and case tracking (Case ID + status flow).
- Field mapping and checklist-template design.
- Organizing information so a human can complete the verification with the
  insurer.

## Current limits

- The workflow does not connect to insurance portals or clearinghouses; a
  person completes the actual verification.
- No complete end-to-end test is claimed yet.
- The email screenshot shows the checklist template configured in Make, not a
  delivered email.

## Screenshots

| File | Shows |
|---|---|
| `screenshots/01-demo-tracker-sheet.png` | The demo tracker with workflow columns (fictional case IDs) |
| `screenshots/02-make-scenario-flow.png` | The Make scenario: Watch New Rows -> checklist email -> Update a Row |
| `screenshots/03-checklist-email-template.png` | The verification checklist email template in Make |

All screenshots are labeled DEMO and use fictional data.
