# Dental Front Desk Automation Portfolio (Demos)

Three documented demo projects by **Verónica Barcia**, built with Make, Google
Sheets, Google Forms, Gmail and Notion. Each project models a real dental front
desk task and shows how it can be organized as a documented, automated workflow.

- LinkedIn: https://www.linkedin.com/in/ver%C3%B3nica-barcia-56a3a6161/
- Upwork: https://www.upwork.com/freelancers/~01ae0157a91964e988
- Public Notion portfolio: https://app.notion.com/p/Ver-nica-Barcia-Portafolio-3f54a9ecd72081f68aebca890bace92e

## Important: about the data in this repository

**All names, dates, phone numbers, emails and case details shown here are
fictional demo data. These are portfolio demonstrations, not client work.**

The workflows are modeled on the reception workflow of my own dental practice.
The demos were never run for real clients or in production. The only execution
was one controlled end-to-end test of the appointment reminders scenario on
October 12, 2026, using a single fictional test row with my own contact data.

No real patient data appears anywhere in this repository.

## Projects

### 01 - Appointment Reminders (Make + Google Sheets + Gmail)

A Make scenario that reads an appointment tracker in Google Sheets, filters the
appointments that need a reminder, sends a reminder email through Gmail, and
marks the row as reminded. Folder: `01-appointment-reminders/`

### 02 - Insurance Verification Intake (Google Forms + Sheets + Make + Gmail)

An intake workflow: a form feeds a tracker in Google Sheets, Make watches for
new cases, prepares a verification checklist email (eligibility, deductible,
coverage percentage, waiting periods, missing tooth clause), and updates the
case status. Folder: `02-insurance-verification-intake/`

### 03 - Dental Front Desk Hub (Notion)

A Notion workspace concept that organizes the daily work of a small clinic:
patient directory, appointment board, recall tracker, front desk tasks, supply
inventory and clinic SOPs. The screenshot is a sanitized recreation with
fictional patients, not captures of a live workspace. Folder:
`03-dental-front-desk-hub/`

## What is NOT in this repository (yet)

The Make scenario export files (blueprint JSON) are intentionally not included.
They contain private connection IDs and account details, and will only be
published after a careful privacy review.

## Español

**Todos los nombres, fechas, teléfonos, correos y casos que aparecen aquí son
datos ficticios de demostración. Son demos de portafolio, no trabajo de
clientes.**

Los flujos están modelados sobre el flujo de recepción de mi propio consultorio
odontológico. Las demos nunca se ejecutaron para clientes reales ni en
producción. La única ejecución fue una prueba controlada de punta a punta del
escenario de recordatorios el 12 de octubre de 2026, con una sola fila de
prueba ficticia y mis propios datos de contacto.

No hay datos de pacientes reales en este repositorio.

Los archivos de exportación de los escenarios de Make (JSON) no se incluyen
todavía: contienen identificadores de conexión privados y solo se publicarán
después de una revisión de privacidad.
