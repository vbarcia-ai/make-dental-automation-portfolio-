# 01 - Dental Appointment Reminders (Demo)

**Tools:** Make, Google Sheets, Gmail
**Status:** Demo with fictional data. Tested end to end on October 12, 2026 with
one fictional test row (my own contact data); the reminder email arrived and the
tracker row was updated. Never run for real clients or in production.

## The problem

Appointment details can be scattered across a tracker and manual email drafts.
Front desk staff spend time checking who needs a reminder and writing each
message by hand, and patients fall through the cracks.

## What this demo does

A Make scenario connects a Google Sheets appointment tracker to a Gmail
reminder template, on a daily schedule:

1. **Search Rows (Google Sheets):** reads the appointment tracker.
2. **Filter:** keeps only the rows that meet the reminder conditions:
   - the appointment is tomorrow,
   - the appointment status is "Confirmed",
   - the patient opted in to reminders,
   - no reminder has been sent yet for that row.
3. **Send an email (Gmail):** maps the patient name, provider, date and time
   into a reminder email template.
4. **Update a Row (Google Sheets):** stamps the row as reminded, with the date,
   so no patient gets two reminders.

## What this project demonstrates

- Turning a repetitive front desk task into a documented, repeatable workflow.
- Mapping data between Google Sheets and a Gmail template.
- Using filters and tracker updates to organize reminder processing safely
  (each row is reminded at most once).

## Current limits

- One controlled end-to-end test ran on October 12, 2026 with a single
  fictional test row; the reminder email arrived and the row was stamped.
- The automatic "tomorrow" date condition is a known open item: during the test
  the date was set manually, and the dynamic version still needs to be built
  with Make's date functions.
- The email screenshots show the template configured in Make, not delivered
  emails.

## Before any production use

Test with authorized recipients only, validate the date handling and row
updates, and confirm patient consent and opt-in wording.

## Screenshots

| File | Shows |
|---|---|
| `screenshots/01-demo-tracker-sheet.png` | The demo tracker in Google Sheets (fictional patients) |
| `screenshots/02-make-scenario-flow.png` | The Make scenario: Search Rows -> filter -> Gmail -> Update a Row |
| `screenshots/03-reminder-email-template.png` | The reminder email template in Make with mapped variables |

All screenshots are labeled DEMO and use fictional data.
